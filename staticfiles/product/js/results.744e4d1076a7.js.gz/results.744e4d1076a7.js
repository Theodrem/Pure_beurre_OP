const sub = document.getElementById("submit");
const name = document.getElementById("name");

sub.addEventListener('click', () => {
        console.log(name);
        });